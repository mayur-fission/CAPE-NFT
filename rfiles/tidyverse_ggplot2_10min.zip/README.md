# Exposure simulation with tidyverse and ggplot2 (10 minutes)

`tidyverse_ggplot2_10min.R` simulates virtual dose-ranging trials (50, 100 and
200 mg once daily, steady state, 50 subjects per dose group) with a
one-compartment oral PK model. It summarises exposure and probability of target
attainment with dplyr, tidyr and purrr and draws the plots with ggplot2. It
repeats for 10 minutes and builds the tables and plots from all trials.

## Setup (once)
- R 4.1 or newer and RStudio
- `install.packages("tidyverse")`

## Run
Set the working directory, then `source("tidyverse_ggplot2_10min.R")`, or click
Source, or run it as a background job. Stop early with the Stop button; tables
and plots are still written.

## Output (`tidyverse_output/` in the working directory)
- `data/sim_dataset_rep001.csv` simulated concentrations for trial 1
- `tables/exposure_by_dose.csv` AUC, Cmax, Ctrough, PTA: median and 95% range
- `tables/replicate_exposure.csv` exposure for every trial
- `tables/vpc_summary.csv` percentiles by dose and time
- `plots/plot_1_individual_profiles.png` individual profiles
- `plots/plot_2_prediction_intervals.png` median and 90% prediction interval
- `plots/plot_3_auc_by_weight.png` exposure by body-weight tertile
- `plots/plot_4_trough_distribution.png` trough distribution against the target
- `logs/` run_log.txt, run_summary.txt, session_info.txt

## Settings (top of the script)
`RUN_MINUTES` (10), `DOSES`, `N_PER_GROUP`, `TARGET_CTROUGH` (0.2 mg/L, a
placeholder: set your own target), `TARGET_REPS_PER_SEC`, `SEED`, `OUT_ROOT`.
