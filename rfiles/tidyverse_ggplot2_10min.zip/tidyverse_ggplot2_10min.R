# ==============================================================================
# Project   : Exposure simulation and plots with tidyverse + ggplot2
# Script    : tidyverse_ggplot2_10min.R
# Purpose   : Simulate virtual dose-ranging trials (50, 100, 200 mg once daily,
#             steady state) with a 1-compartment oral PK model, summarise
#             exposure and probability of target attainment (PTA) with dplyr /
#             tidyr / purrr, and draw PK plots with ggplot2. Repeats the
#             simulation for RUN_MINUTES (default 10), then writes tables and
#             PNG plots built from all replicates.
# Model     : CL (L/h), V (L), KA (1/h); allometric WT effect; log-normal BSV
#             (CL-V correlation 0.5); combined proportional + additive error
# Software  : R with the tidyverse (install.packages("tidyverse"))
# Run       : source() in the RStudio console, Source button, background job,
#             or Rscript. Stop early with Stop / Esc / Ctrl+C (tables and
#             plots are still written).
# Output    : ./tidyverse_output/{data,tables,plots,logs}
# Units     : time h, dose mg, concentration mg/L, AUC mg*h/L
# ==============================================================================

# ---- 0. Packages --------------------------------------------------------------
if (!requireNamespace("tidyverse", quietly = TRUE)) {
  stop("Package 'tidyverse' is not installed. Run: install.packages(\"tidyverse\")")
}
suppressPackageStartupMessages(library(tidyverse))

# ---- 1. Run control -----------------------------------------------------------
RUN_MINUTES         <- 10     # total wall-clock run time (including plotting)
PLOT_RESERVE_SECONDS <- 10    # time kept at the end for tables and plots
DOSES               <- c(50, 100, 200)   # mg once daily
N_PER_GROUP         <- 50     # subjects per dose group per replicate
TARGET_REPS_PER_SEC <- 4      # pacing; Inf = flat out
LOG_EVERY_SECONDS   <- 30
TARGET_CTROUGH      <- 0.2    # mg/L, PTA threshold (placeholder)
SEED                <- 20261022
OUT_ROOT            <- file.path(getwd(), "tidyverse_output")

# ---- 2. Model -------------------------------------------------------------------
THETA      <- c(CL = 5, V = 50, KA = 1.0)
OMEGA_SD   <- c(CL = 0.30, V = 0.25, KA = 0.40)
OMEGA_CORR <- matrix(c(1, 0.5, 0, 0.5, 1, 0, 0, 0, 1), 3, 3)
OMEGA      <- OMEGA_CORR * outer(OMEGA_SD, OMEGA_SD)
SIGMA_PROP <- 0.15
SIGMA_ADD  <- 0.02
TAU        <- 24
OBS_TIMES  <- c(0, 0.5, 1, 1.5, 2, 3, 4, 6, 8, 10, 12, 16, 20, 24)
GRID       <- seq(0, TAU, by = 0.25)

# ---- 3. Directories and logging --------------------------------------------------
dirs <- file.path(OUT_ROOT, c("data", "tables", "plots", "logs"))
for (d in dirs) {
  if (!dir.exists(d)) dir.create(d, recursive = TRUE)
  if (!dir.exists(d)) stop("Cannot create directory: ", d)
}
invisible(file.remove(list.files(dirs,
  pattern = "^(sim_dataset_rep001|exposure_by_dose|replicate_exposure|vpc_summary|plot_|run_summary|run_log|session_info)",
  full.names = TRUE)))
RUN_LOG <- file.path(OUT_ROOT, "logs", "run_log.txt")
t_start <- Sys.time()
elapsed <- function() as.numeric(difftime(Sys.time(), t_start, units = "secs"))
say <- function(...) {
  msg <- sprintf("[%7.1fs] %s", elapsed(), sprintf(...))
  cat(msg, "\n", sep = ""); flush.console()
  cat(msg, "\n", sep = "", file = RUN_LOG, append = TRUE)
}
set.seed(SEED)
writeLines(capture.output(sessionInfo()), file.path(OUT_ROOT, "logs", "session_info.txt"))

# ---- 4. Functions ------------------------------------------------------------------
# Steady-state concentration for once-daily oral dosing (t within one interval)
conc_ss <- function(t, dose, cl, v, ka) {
  k  <- cl / v
  ka <- if_else(abs(ka - k) < 1e-4, ka + 1e-3, ka)
  dose * ka / (v * (ka - k)) *
    (exp(-k * t) / (1 - exp(-k * TAU)) - exp(-ka * t) / (1 - exp(-ka * TAU)))
}

simulate_trial <- function(rep_id) {
  n   <- N_PER_GROUP * length(DOSES)
  eta <- matrix(rnorm(n * 3), n, 3) %*% chol(OMEGA)
  tibble(ID = seq_len(n), DOSE = rep(DOSES, each = N_PER_GROUP),
         WT = pmin(pmax(70 * exp(rnorm(n, 0, 0.20)), 40), 140),
         SEX = sample(c("F", "M"), n, replace = TRUE)) |>
    mutate(CL = THETA[["CL"]] * (WT / 70)^0.75 * exp(eta[, 1]),
           V  = THETA[["V"]]  * (WT / 70)      * exp(eta[, 2]),
           KA = THETA[["KA"]] * exp(eta[, 3]),
           WT_GRP = cut(WT, quantile(WT, c(0, 1/3, 2/3, 1)), include.lowest = TRUE,
                        labels = c("Low WT", "Mid WT", "High WT")),
           REP = rep_id)
}

exposure_by_subject <- function(subj) {
  subj |>
    mutate(AUCTAU = DOSE / CL, CTROUGH = conc_ss(0, DOSE, CL, V, KA)) |>
    left_join(
      subj |> select(ID, DOSE, CL, V, KA) |>
        crossing(TIME = GRID) |>
        mutate(C = conc_ss(TIME, DOSE, CL, V, KA)) |>
        group_by(ID) |> summarise(CMAX = max(C), .groups = "drop"),
      by = "ID")
}

observations <- function(subj) {
  subj |> select(ID, DOSE, WT, WT_GRP, SEX, CL, V, KA, REP) |>
    crossing(TIME = OBS_TIMES) |>
    mutate(IPRED = conc_ss(TIME, DOSE, CL, V, KA),
           DV = pmax(IPRED * (1 + rnorm(n(), 0, SIGMA_PROP)) + rnorm(n(), 0, SIGMA_ADD), 0)) |>
    arrange(ID, TIME)
}

geomean <- function(x) exp(mean(log(x)))

# ---- 5. Main loop --------------------------------------------------------------------
say("Output directory: %s", normalizePath(OUT_ROOT))
say("Simulating dose groups %s mg x %d subjects for %.1f min",
    paste(DOSES, collapse = "/"), N_PER_GROUP, RUN_MINUTES)

expo_list <- list(); vpc_list <- list(); wt_list <- list()
n_rep <- 0; last_log <- 0; stop_reason <- "completed"; first_obs <- NULL

tryCatch({
  while (elapsed() < RUN_MINUTES * 60 - PLOT_RESERVE_SECONDS) {
    n_rep <- n_rep + 1
    subj <- simulate_trial(n_rep)
    ex   <- exposure_by_subject(subj)
    obs  <- observations(subj)
    if (n_rep == 1) { first_obs <- obs; first_ex <- ex }

    expo_list[[n_rep]] <- ex |>
      group_by(REP, DOSE) |>
      summarise(N = n(), AUCTAU_GM = geomean(AUCTAU), CMAX_GM = geomean(CMAX),
                CTROUGH_GM = geomean(CTROUGH), PTA = mean(CTROUGH >= TARGET_CTROUGH),
                .groups = "drop")
    vpc_list[[n_rep]] <- obs |>
      group_by(REP, DOSE, TIME) |>
      summarise(P05 = quantile(DV, 0.05), P50 = median(DV), P95 = quantile(DV, 0.95),
                .groups = "drop")
    wt_list[[n_rep]] <- ex |> filter(DOSE == 100) |>
      group_by(REP, WT_GRP) |> summarise(AUCTAU_GM = geomean(AUCTAU), .groups = "drop")

    if (elapsed() - last_log >= LOG_EVERY_SECONDS) {
      last <- expo_list[[n_rep]]
      say("replicate %5d | AUCtau GM (50/100/200 mg): %s", n_rep,
          paste(sprintf("%.1f", last$AUCTAU_GM), collapse = " / "))
      last_log <- elapsed()
    }
    if (is.finite(TARGET_REPS_PER_SEC)) {
      ahead <- n_rep / TARGET_REPS_PER_SEC - elapsed()
      if (ahead > 0) Sys.sleep(ahead)
    }
  }
}, interrupt = function(e) {
  stop_reason <<- "stopped manually"
}, error = function(e) {
  stop_reason <<- paste("error:", conditionMessage(e))
  message("ERROR: ", conditionMessage(e))
})

# ---- 6. Tables and plots (also after a manual stop) ----------------------------------------
plot_note <- "plots written"
if (n_rep > 0) {
  expo <- bind_rows(expo_list); vpc <- bind_rows(vpc_list); wtg <- bind_rows(wt_list)

  write_csv(first_obs |> mutate(across(where(is.double), \(x) round(x, 4))),
            file.path(OUT_ROOT, "data", "sim_dataset_rep001.csv"))
  write_csv(expo |> mutate(across(where(is.double), \(x) round(x, 5))),
            file.path(OUT_ROOT, "tables", "replicate_exposure.csv"))

  expo_sum <- expo |>
    group_by(DOSE) |>
    summarise(across(c(AUCTAU_GM, CMAX_GM, CTROUGH_GM, PTA),
                     list(MEDIAN = median, LO95 = \(x) quantile(x, 0.025), HI95 = \(x) quantile(x, 0.975)),
                     .names = "{.col}_{.fn}"), .groups = "drop") |>
    mutate(across(where(is.double), \(x) round(x, 4)))
  write_csv(expo_sum, file.path(OUT_ROOT, "tables", "exposure_by_dose.csv"))

  vpc_sum <- vpc |>
    group_by(DOSE, TIME) |>
    summarise(P05_MED = median(P05), P50_MED = median(P50), P95_MED = median(P95),
              P50_LO = quantile(P50, 0.05), P50_HI = quantile(P50, 0.95), .groups = "drop") |>
    mutate(across(where(is.double), \(x) round(x, 5)))
  write_csv(vpc_sum, file.path(OUT_ROOT, "tables", "vpc_summary.csv"))

  plot_note <- tryCatch({
    dose_lab <- \(x) paste(x, "mg QD")
    theme_set(theme_bw(base_size = 12))
    pal <- scale_colour_viridis_d(end = 0.85)

    p1 <- first_obs |> mutate(DOSE_F = factor(DOSE, DOSES, dose_lab(DOSES))) |>
      ggplot(aes(TIME, DV, group = ID, colour = DOSE_F)) +
      geom_line(alpha = 0.35, linewidth = 0.4) +
      scale_y_log10() + pal + facet_wrap(~DOSE_F) +
      labs(x = "Time after dose (h)", y = "Concentration (mg/L, log scale)",
           colour = NULL, title = "Individual steady-state profiles (replicate 1)") +
      theme(legend.position = "none")
    ggsave(file.path(OUT_ROOT, "plots", "plot_1_individual_profiles.png"), p1, width = 9, height = 5, dpi = 110)

    p2 <- vpc_sum |> mutate(DOSE_F = factor(DOSE, DOSES, dose_lab(DOSES))) |>
      ggplot(aes(TIME)) +
      geom_ribbon(aes(ymin = P05_MED, ymax = P95_MED, fill = DOSE_F), alpha = 0.2) +
      geom_ribbon(aes(ymin = P50_LO, ymax = P50_HI, fill = DOSE_F), alpha = 0.5) +
      geom_line(aes(y = P50_MED, colour = DOSE_F), linewidth = 0.9) +
      scale_colour_viridis_d(end = 0.85) + scale_fill_viridis_d(end = 0.85) +
      facet_wrap(~DOSE_F) +
      labs(x = "Time after dose (h)", y = "Concentration (mg/L)",
           title = sprintf("Median and 90%% prediction interval (%d replicates)", n_rep)) +
      theme(legend.position = "none")
    ggsave(file.path(OUT_ROOT, "plots", "plot_2_prediction_intervals.png"), p2, width = 9, height = 5, dpi = 110)

    p3 <- first_ex |> filter(DOSE == 100) |>
      ggplot(aes(WT_GRP, AUCTAU, fill = WT_GRP)) +
      geom_boxplot(outlier.shape = NA, alpha = 0.6) + geom_jitter(width = 0.15, size = 1, alpha = 0.6) +
      scale_fill_viridis_d(end = 0.85) +
      labs(x = NULL, y = "AUCtau at steady state (mg*h/L)",
           title = "Exposure by body-weight tertile, 100 mg QD (replicate 1)") +
      theme(legend.position = "none")
    ggsave(file.path(OUT_ROOT, "plots", "plot_3_auc_by_weight.png"), p3, width = 7, height = 5, dpi = 110)

    p4 <- expo |> mutate(DOSE_F = factor(DOSE, DOSES, dose_lab(DOSES))) |>
      ggplot(aes(CTROUGH_GM, fill = DOSE_F)) +
      geom_histogram(bins = 40, alpha = 0.8) +
      geom_vline(xintercept = TARGET_CTROUGH, linetype = 2) +
      scale_fill_viridis_d(end = 0.85) + facet_wrap(~DOSE_F, scales = "free_y") +
      labs(x = "Geometric-mean trough concentration per replicate (mg/L)", y = "Replicates",
           title = "Trough concentration across replicates (dashed line = target)") +
      theme(legend.position = "none")
    ggsave(file.path(OUT_ROOT, "plots", "plot_4_trough_distribution.png"), p4, width = 9, height = 4.5, dpi = 110)
    "4 plots written"
  }, error = function(e) paste("plot error:", conditionMessage(e)))
}

# use any time left so the whole run lasts RUN_MINUTES
if (stop_reason == "completed" && elapsed() < RUN_MINUTES * 60) {
  Sys.sleep(RUN_MINUTES * 60 - elapsed())
}

summ <- c("EXPOSURE SIMULATION (tidyverse + ggplot2) - RUN SUMMARY",
          sprintf("Finished because: %s", stop_reason),
          sprintf("Runtime:          %.1f s (%.2f min)", elapsed(), elapsed() / 60),
          sprintf("Replicates:       %d trials x %d subjects", n_rep, N_PER_GROUP * length(DOSES)),
          sprintf("Plots:            %s", plot_note),
          sprintf("Output directory: %s", normalizePath(OUT_ROOT)))
writeLines(summ, file.path(OUT_ROOT, "logs", "run_summary.txt"))
cat("\n", paste(summ, collapse = "\n"), "\n", sep = "")
if (n_rep > 0) { cat("\nExposure by dose (median across replicates):\n"); print(expo_sum, width = 120) }
