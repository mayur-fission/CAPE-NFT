# mrgsolve_sim.R

Population PK simulation with mrgsolve (1-compartment oral, 100 mg QD x 7 days).
Runs about 10 minutes, then writes nothing more; saves replicate 1 only to
`mrgsolve_output/sim_rep001.csv` (67,400 rows x 10 columns, roughly 8-12 MB).

## Setup (once)
1. Install R (4.1 or newer) and RStudio.
2. Install a C++ compiler: Rtools on Windows (match your R version),
   `xcode-select --install` on Mac, `sudo apt install build-essential` on Linux.
3. In the console: `install.packages("mrgsolve")`
4. Check: `library(mrgsolve); modlib("pk1") |> ev(amt = 100) |> mrgsim() |> plot()`

## Run
Set the working directory to this folder, then `source("mrgsolve_sim.R")`.
The first run spends 10-60 s compiling the model before the 10 minutes start.
Stop early with the Stop button.

## Notes
- Smaller output: set `n <- 10` and `delta = 2`.
