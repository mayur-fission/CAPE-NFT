# ==============================================================================
# mrgsolve_sim.R
# Population PK simulation with mrgsolve: 1-compartment oral model, allometric
# WT effect, log-normal BSV (CL-V correlation 0.5), combined residual error.
# Dosing: 100 mg QD x 7 days (ii = 24, addl = 6). Runs for about 10 minutes
# (RUN_SECONDS) simulating replicates of 200 subjects; saves replicate 1 only.
# Requires: install.packages("mrgsolve") and a C++ compiler (Rtools on Windows).
# Output: ./mrgsolve_output/sim_rep001.csv   (units: h, mg, mg/L)
# Stop early with the Stop button / Esc.
# ==============================================================================
library(mrgsolve)

code <- '
$PARAM CL = 5, V = 50, KA = 1, WT = 70
$CMT GUT CENT
$OMEGA @block @labels ECL EV
0.09
0.0375 0.0625
$OMEGA @labels EKA
0.16
$SIGMA 0.0225 0.0004
$MAIN
double cl = CL * pow(WT/70, 0.75) * exp(ECL);
double v  = V  * (WT/70) * exp(EV);
double ka = KA * exp(EKA);
$ODE
dxdt_GUT  = -ka * GUT;
dxdt_CENT = ka * GUT - (cl/v) * CENT;
$TABLE
double IPRED = CENT / v;
double DV = IPRED * (1 + EPS(1)) + EPS(2);
$CAPTURE IPRED DV cl v ka WT
'
mod  <- mcode("pk_oral", code)
dose <- ev(amt = 100, ii = 24, addl = 6, cmt = "GUT")

dir.create("mrgsolve_output", showWarnings = FALSE)
RUN_SECONDS <- 10 * 60
t0 <- Sys.time(); rep_id <- 0; first <- TRUE

while (as.numeric(difftime(Sys.time(), t0, units = "secs")) < RUN_SECONDS) {
  rep_id <- rep_id + 1
  n <- 200
  idata <- data.frame(ID = 1:n, WT = pmin(pmax(70 * exp(rnorm(n, 0, 0.2)), 40), 140))
  out <- mod |> ev(dose) |> idata_set(idata) |>
         mrgsim(end = 168, delta = 0.5, obsonly = TRUE) |> as.data.frame()
  if (first) {   # save the first replicate as the output dataset
    write.csv(out, "mrgsolve_output/sim_rep001.csv", row.names = FALSE)
    first <- FALSE
  }
  cat(sprintf("[%6.1fs] replicate %d done\n",
              as.numeric(difftime(Sys.time(), t0, units = "secs")), rep_id))
  Sys.sleep(0.2)
}
cat("Finished", rep_id, "replicates\n")
