# Version-control status polling, as a live user session does it (R)

`vcs_status_poll.R` reproduces what every Workbench session does in
production: refresh the version-control status of its working copy every
10 seconds - `git status` for Bitbucket repositories, `svn status` for SVN
working copies - on a large repository (~150,000 files) on shared network
storage, in the background while the user works. Every call is timed, so a
load test shows how status calls slow down as sessions are added. Base R
only; needs `git` and/or `svn` on the server.

## Why it is realistic
- **Fixed 10-second timer** per session; a slow call delays the next one,
  calls of one session never overlap (recorded as "late starts").
- **Random start** within the first interval: real users open sessions at
  different moments, so 200 sessions do not all hit the storage in the same
  second.
- **Working copy only**: `git status --porcelain` / `svn status
  --non-interactive` read the local working copy, never the remote server.
- **Background mode** keeps the session free for real work, as in production
  where the refresh runs alongside whatever the user is doing.

## Settings (environment variables, or edit section 1)
| Variable | Default | Meaning |
|---|---|---|
| `VCS_POLL_REPO` | (required) | Working copy to poll |
| `VCS_POLL_VCS` | `auto` | `git`, `svn`, or `auto` (looks for `.git` / `.svn`) |
| `VCS_POLL_INTERVAL_SECONDS` | `10` | Time between calls |
| `VCS_POLL_RANDOM_START` | `true` | Random first call within the first interval |
| `VCS_POLL_BACKGROUND` | `false` | `true` = start a separate poller process and return |
| `VCS_POLL_RUN_MINUTES` | `Inf` (foreground), `240` (background) | Maximum run time |
| `VCS_POLL_CALL_TIMEOUT_SECONDS` | `300` | A call taking longer is stopped and counted as failed |
| `VCS_POLL_STATUS_ARGS` | `status --porcelain` / `status --non-interactive` | Use production's exact command if it differs |

Set them in `~/.Renviron` on the server (applies to new sessions), or with
`Sys.setenv()` before `source()`.

## Run
- **Foreground** (e.g. sessions whose tabs are closed during a test):
  `source("vcs_status_poll.R")` - polls until stopped with Stop / Esc /
  Ctrl+C; the summary is still written.
- **Background** (e.g. sessions that also run an analysis script):
  `Sys.setenv(VCS_POLL_BACKGROUND = "true"); source("vcs_status_poll.R")`
  returns at once. The poller stops when the session ends, when
  `vcs_poll_output/logs/STOP` is created, or after `VCS_POLL_RUN_MINUTES`.

## Outputs (`vcs_poll_output/logs/` in the working directory)
- `status_calls.csv` - one row per call: time, call number, vcs, seconds,
  exit code, changed entries, late start (s), error
- `run_log.txt` - a progress line every minute
- `run_summary.txt` - call count, median / p95 / max call time, late starts,
  errors (lock errors on git's `index.lock` or SVN's `wc.db` are named)
- `poller_errors.txt` - background mode: anything the poller process printed

## Caution
On shared network storage, many sessions polling a ~150,000-file repository
load that storage for everyone using it. Agree test runs with the storage
owners, use a test copy of the repository where possible, and start small
(20-50 sessions).
