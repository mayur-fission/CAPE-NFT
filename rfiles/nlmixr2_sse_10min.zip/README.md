# Population PK simulate-estimate with nlmixr2 (10 minutes)

`nlmixr2_sse_10min.R` repeats a simulate-estimate cycle for 10 minutes:
1. simulate a 40-subject study (100 mg single oral dose, 13 samples to 48 h)
   from a known one-compartment model with between-subject variability and
   combined residual error,
2. fit it with nlmixr2 (FOCEi) from deliberately wrong starting values,
3. record how well the true parameters are recovered (bias and RMSE).

## Setup (once)
- R 4.1 or newer and RStudio
- A C/C++ compiler (rxode2 compiles the model): Rtools on Windows (match your R
  version), `xcode-select --install` on Mac, `sudo apt install build-essential`
  on Linux
- `install.packages("nlmixr2")`

## Run
Set the working directory, then `source("nlmixr2_sse_10min.R")`, or click Source,
or run it as a background job. The first fit takes longer because the model is
compiled. Stop early with the Stop button; the summary is still written.

## Output (`nlmixr2_output/` in the working directory)
- `data/nlmixr2_dataset_rep001.csv` the first simulated NONMEM-style dataset
- `tables/sse_estimates.csv` estimates from every fit
- `tables/sse_summary.csv` true value, median estimate, relative bias and RMSE
- `logs/fit_rep001.txt` full nlmixr2 output for the first fit
- `logs/` run_log.txt, run_summary.txt, session_info.txt

## Settings (top of the script)
`RUN_MINUTES` (10), `N_SUBJ` (40), `DOSE`, `OBS_TIMES`, `SEED`, `OUT_ROOT`. The model
and true values are in `pk_model()` and are illustrative.

## Expected result
Runs 10 minutes (about 60 fits at roughly 8 s each; the number depends on your
computer). CL, V and KA are recovered within a few percent. The additive error SD
is small and poorly identified, so its estimate is less accurate. That is normal.
