# ============================================================================
# high_throughput_sim.R
#
# Simulates a HIGH-THROUGHPUT event pipeline in base R (no packages needed):
#   * generates a continuous stream of events in batches (default 10,000
#     events/second),
#   * writes every event to rotating CSV files (events_part_001.csv, ...),
#   * keeps running per-region aggregates and writes them once per minute,
#   * logs measured throughput every few seconds,
#   * stops by itself after RUN_MINUTES (default 10 minutes).
#
# OUTPUT (all inside ./throughput_output under the current working directory):
#   events_part_NNN.csv   raw events, rotated every ROTATE_ROWS rows
#   aggregates.csv        per-region totals, appended once per minute
#   throughput_log.csv    events/sec measured every LOG_EVERY_SECONDS
#   run_summary.txt       final summary of the run
#
# DEFAULT SIZE: 10,000 events/s x 600 s = 6,000,000 events, roughly 400 MB.
# Need less disk? Lower TARGET_EVENTS_PER_SEC. Want more load? Raise it
# (set it to Inf to run flat out; the run still ends after RUN_MINUTES, but
# then the output can reach many GB).
#
# HOW TO RUN: Source it in RStudio / Workbench, run it as a background job,
# or `Rscript high_throughput_sim.R`. To stop early: Stop button / Esc /
# Ctrl+C - files are closed cleanly and a summary is still written.
# ============================================================================

## ---------------------------- CONFIGURATION -------------------------------
RUN_MINUTES          <- 10        # total run time
TARGET_EVENTS_PER_SEC <- 10000    # target rate (Inf = as fast as possible)
BATCH_SIZE           <- 5000      # events generated/written per batch
ROTATE_ROWS          <- 1e6       # start a new events file after this many rows
LOG_EVERY_SECONDS    <- 10        # throughput log interval
OUTPUT_DIR           <- file.path(getwd(), "throughput_output")
RANDOM_SEED          <- 42
## --------------------------------------------------------------------------

set.seed(RANDOM_SEED)
RUN_SECONDS <- RUN_MINUTES * 60

if (!dir.exists(OUTPUT_DIR)) dir.create(OUTPUT_DIR, recursive = TRUE)
if (!dir.exists(OUTPUT_DIR)) stop("Cannot create output directory: ", OUTPUT_DIR)

# Start clean so repeated runs do not mix with old files.
old <- list.files(OUTPUT_DIR, pattern = "^(events_part_.*\\.csv|aggregates\\.csv|throughput_log\\.csv|run_summary\\.txt)$",
                  full.names = TRUE)
if (length(old)) invisible(file.remove(old))

regions     <- c("north", "south", "east", "west", "central")
event_types <- c("view", "click", "add_to_cart", "purchase", "refund")
statuses    <- c("ok", "ok", "ok", "ok", "ok", "ok", "ok", "ok", "retry", "error")
type_probs  <- c(0.55, 0.25, 0.10, 0.08, 0.02)

EVENT_COLS <- c("event_id", "timestamp", "user_id", "region", "event_type",
                "amount", "latency_ms", "status")

make_batch <- function(first_id, n, t0) {
  data.frame(
    event_id   = seq.int(first_id, length.out = n),
    timestamp  = format(t0 + sort(runif(n, 0, 1)), "%Y-%m-%d %H:%M:%OS3"),
    user_id    = sample.int(100000L, n, replace = TRUE),
    region     = sample(regions, n, replace = TRUE),
    event_type = sample(event_types, n, replace = TRUE, prob = type_probs),
    amount     = round(rlnorm(n, meanlog = 3, sdlog = 0.8), 2),
    latency_ms = round(rgamma(n, shape = 2, rate = 0.04), 1),
    status     = sample(statuses, n, replace = TRUE),
    stringsAsFactors = FALSE
  )
}

write_rows <- function(con, df) {
  write.table(df, file = con, sep = ",", row.names = FALSE, col.names = FALSE,
              quote = FALSE)
}

# ------------------------------ state -------------------------------------
start_time    <- Sys.time()
elapsed       <- function() as.numeric(difftime(Sys.time(), start_time, units = "secs"))
total_events  <- 0
total_bytes   <- 0
part_index    <- 0
rows_in_part  <- 0
con           <- NULL
last_log_t    <- 0
last_log_ev   <- 0
last_agg_t    <- 0
behind_count  <- 0
agg_count     <- setNames(numeric(length(regions)), regions)
agg_amount    <- setNames(numeric(length(regions)), regions)
agg_latency   <- setNames(numeric(length(regions)), regions)

open_new_part <- function() {
  if (!is.null(con)) close(con)
  part_index  <<- part_index + 1
  rows_in_part <<- 0
  path <- file.path(OUTPUT_DIR, sprintf("events_part_%03d.csv", part_index))
  con  <<- file(path, open = "w")
  writeLines(paste(EVENT_COLS, collapse = ","), con)
  invisible(path)
}

agg_file <- file.path(OUTPUT_DIR, "aggregates.csv")
log_file <- file.path(OUTPUT_DIR, "throughput_log.csv")
writeLines("elapsed_s,region,events,total_amount,avg_latency_ms", agg_file)
writeLines("elapsed_s,events_total,events_per_sec_interval,events_per_sec_overall,mb_written,behind_schedule_batches", log_file)

flush_aggregates <- function() {
  avg_lat <- ifelse(agg_count > 0, agg_latency / agg_count, 0)
  df <- data.frame(elapsed_s = round(elapsed(), 1), region = regions,
                   events = as.numeric(agg_count[regions]),
                   total_amount = round(as.numeric(agg_amount[regions]), 2),
                   avg_latency_ms = round(as.numeric(avg_lat[regions]), 2))
  write.table(df, agg_file, sep = ",", row.names = FALSE, col.names = FALSE,
              quote = FALSE, append = TRUE)
}

write_summary <- function(reason) {
  s <- c(
    "HIGH-THROUGHPUT SIMULATION SUMMARY",
    sprintf("Finished because:      %s", reason),
    sprintf("Runtime:               %.1f s (%.2f min)", elapsed(), elapsed() / 60),
    sprintf("Events written:        %s", format(total_events, big.mark = ",", scientific = FALSE)),
    sprintf("Average throughput:    %.0f events/s", total_events / max(elapsed(), 1e-9)),
    sprintf("Target throughput:     %s events/s", format(TARGET_EVENTS_PER_SEC, scientific = FALSE)),
    sprintf("Batches behind sched.: %d", behind_count),
    sprintf("Event files:           %d", part_index),
    sprintf("Output size:           %.1f MB", sum(file.info(list.files(OUTPUT_DIR, full.names = TRUE))$size) / 1024^2),
    sprintf("Output directory:      %s", normalizePath(OUTPUT_DIR))
  )
  writeLines(s, file.path(OUTPUT_DIR, "run_summary.txt"))
  cat("\n", paste(s, collapse = "\n"), "\n", sep = "")
}

# ------------------------------ main loop ---------------------------------
cat("Output directory:", normalizePath(OUTPUT_DIR), "\n")
cat(sprintf("Running for %.1f min at target %s events/s (batch = %d)...\n",
            RUN_MINUTES, format(TARGET_EVENTS_PER_SEC, scientific = FALSE), BATCH_SIZE))

reason <- "completed"
tryCatch({
  open_new_part()
  while (elapsed() < RUN_SECONDS) {
    n  <- BATCH_SIZE
    df <- make_batch(total_events + 1, n, Sys.time())

    if (rows_in_part + n > ROTATE_ROWS) open_new_part()
    write_rows(con, df)
    rows_in_part <- rows_in_part + n
    total_events <- total_events + n

    # running aggregates by region
    agg_count   <- agg_count   + as.numeric(table(factor(df$region, regions)))
    agg_amount  <- agg_amount  + as.numeric(tapply(df$amount,     factor(df$region, regions), sum, default = 0))
    agg_latency <- agg_latency + as.numeric(tapply(df$latency_ms, factor(df$region, regions), sum, default = 0))

    # per-minute aggregate snapshot
    if (elapsed() - last_agg_t >= 60) { flush_aggregates(); last_agg_t <- elapsed() }

    # throughput log
    now <- elapsed()
    if (now - last_log_t >= LOG_EVERY_SECONDS) {
      flush(con)
      interval_rate <- (total_events - last_log_ev) / max(now - last_log_t, 1e-9)
      mb <- sum(file.info(list.files(OUTPUT_DIR, pattern = "^events_part_", full.names = TRUE))$size) / 1024^2
      cat(sprintf("[%6.1fs] %9s events | %7.0f ev/s (interval) | %7.0f ev/s (overall) | %6.1f MB\n",
                  now, format(total_events, big.mark = ",", scientific = FALSE), interval_rate,
                  total_events / now, mb))
      cat(sprintf("%.1f,%d,%.0f,%.0f,%.1f,%d\n", now, total_events, interval_rate,
                  total_events / now, mb, behind_count),
          file = log_file, append = TRUE)
      flush.console()
      last_log_t <- now; last_log_ev <- total_events
    }

    # pacing: sleep only if we are ahead of the target rate
    if (is.finite(TARGET_EVENTS_PER_SEC)) {
      ahead <- total_events / TARGET_EVENTS_PER_SEC - elapsed()
      if (ahead > 0) Sys.sleep(ahead) else behind_count <- behind_count + 1
    }
  }
}, interrupt = function(e) {
  reason <<- "stopped manually"
}, error = function(e) {
  reason <<- paste("error:", conditionMessage(e))
  message("ERROR: ", conditionMessage(e))
}, finally = {
  if (!is.null(con)) { try(close(con), silent = TRUE); con <- NULL }
  try(flush_aggregates(), silent = TRUE)
  write_summary(reason)
})
