# High-throughput simulation (R) - 10 minute run

`high_throughput_sim.R` simulates a high-throughput event pipeline in base R
(no packages to install). For 10 minutes it generates events in batches,
writes them to rotating CSV files, keeps per-region aggregates and logs
measured throughput.

## Run it
- RStudio / Workbench console: `source("high_throughput_sim.R")`
- Source button or a background job both work
- Terminal: `Rscript high_throughput_sim.R`

Output goes to `throughput_output/` inside the current working directory
(the full path is printed at start). Stop early with the Stop button, Esc or
Ctrl+C - files are closed cleanly and a summary is still written.

## Output files
| File | Contents |
|---|---|
| `events_part_001.csv` ... | raw events (event_id, timestamp, user_id, region, event_type, amount, latency_ms, status), a new file every 1,000,000 rows |
| `aggregates.csv` | per-region event count, total amount, avg latency, snapshot once a minute plus a final one |
| `throughput_log.csv` | events/sec (interval and overall), MB written, every 10 s |
| `run_summary.txt` | final totals and average throughput |

Default load: 10,000 events/s x 600 s = about 6,000,000 events, roughly 360 MB.

## Settings (top of the script)
`RUN_MINUTES` (10), `TARGET_EVENTS_PER_SEC` (10000; `Inf` = flat out, but
output can then reach many GB), `BATCH_SIZE` (5000), `ROTATE_ROWS` (1e6),
`LOG_EVERY_SECONDS` (10), `OUTPUT_DIR`, `RANDOM_SEED`.

## How timing works
Batches are paced against the target rate (the script sleeps only when it is
ahead of schedule), and the loop ends when 10 minutes of wall-clock time
have passed. If the machine cannot sustain the rate, it simply runs
unpaced and counts the "behind schedule" batches in the summary.
