# Population PK simulation - ~10 KB NONMEM-style dataset, 10 minute run (R)

`pmx_10kb_10min.R` is laid out like a pharmacometrics simulation script:
header block (purpose, model, dosing, units), run control, THETA/OMEGA/SIGMA
model specification, dosing and sampling design, functions, simulation,
post-processing and logged outputs. Base R only - no packages to install.

## Model
- One-compartment oral PK, analytical solution: CL 5 L/h, V 50 L, KA 1 /h (70 kg)
- Allometric WT effect (CL 0.75, V 1.0); covariates WT, SEX, AGE
- Log-normal BSV: CL 30%, V 25%, KA 40%, corr(CL,V) = 0.5
- Combined residual error (15% proportional + 0.02 mg/L additive);
  BLQ (LLOQ 0.05 mg/L) handled M5-style (LLOQ/2, flagged)
- 100 mg QD x 7 days, written NONMEM-style as one dose record with
  ADDL = 6, II = 24; rich sampling on day 1 and day 7

## What it does
1. Writes `data/nm_dataset.csv`, a NONMEM-format dataset of about 10 KB
   (whole subjects only, so it lands just under 10 KB; about 9.6 KB, 18
   subjects, 15 records each). Columns: ID, TIME, AMT, ADDL, II, DV, EVID,
   CMT, MDV, BLQ, WT, SEX, AGE; missing values are ".".
2. For the rest of the 10 minutes it simulates virtual-trial replicates
   (200 subjects each, about 5 per second) and tracks steady-state AUCtau,
   Cmax, Ctrough and the probability of target attainment (Ctrough >= 0.2 mg/L,
   a placeholder - set your own target).
3. At the end it writes `tables/exposure_summary.csv` (median and 95% range
   across replicates) and logs.

## Outputs (`pmx_10kb_output/` in the working directory)
`data/nm_dataset.csv`, `tables/exposure_summary.csv`, `logs/run_log.txt`,
`logs/model_spec.txt`, `logs/session_info.txt`, `logs/run_summary.txt`.
The dataset is the ~10 KB data file; the other files are small logs.

## Run
`source("pmx_10kb_10min.R")` in the RStudio console, the Source button, a
background job, or `Rscript pmx_10kb_10min.R`. The output path is printed at
start. Stop early with Stop / Esc / Ctrl+C - the summaries are still written.
Settings (`RUN_MINUTES`, `TARGET_DATA_BYTES`, pacing, seed) are at the top.
