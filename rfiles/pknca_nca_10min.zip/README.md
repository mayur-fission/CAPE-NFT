# NCA simulation check with PKNCA (10 minutes)

`pknca_nca_10min.R` simulates single-dose oral PK profiles (100 mg, 40 subjects
per virtual trial, 14 samples to 48 h), runs non-compartmental analysis with
PKNCA on every trial for 10 minutes, and compares the NCA estimates with the
true model values (for example NCA CL/F against the simulated CL).

## Setup (once)
- R 4.1 or newer and RStudio
- `install.packages("PKNCA")`

## Run
Set the working directory (Session > Set Working Directory), then
`source("pknca_nca_10min.R")`, or click Source, or run it as a background job.
Stop early with the Stop button; the summary is still written.

## Output (`pknca_output/` in the working directory)
- `data/nca_subject_results_rep001.csv` NCA results per subject for trial 1
  (Cmax, Tmax, AUClast, AUCinf, half-life, CL/F, Vz/F) with the true values
- `tables/nca_replicate_summary.csv` geometric means and bias per trial
- `tables/nca_summary.csv` median and 95% range across trials
- `logs/` run_log.txt, run_summary.txt, session_info.txt

## Settings (top of the script)
`RUN_MINUTES` (10), `N_SUBJ` (40), `TARGET_REPS_PER_SEC` (1), `SEED`, `OUT_ROOT`.
The model values (CL 5 L/h, V 50 L, KA 1 /h, 30/25/40% variability, 15% + 0.02
mg/L error) are illustrative. Replace them with your own.

## Expected result
Runs about 10 minutes (hundreds of trials, fewer on a slower computer). The
NCA CL/F should agree with the true CL within a few percent (bias near 0%).
