# ==============================================================================
# Project   : Non-compartmental analysis (NCA) with PKNCA - simulation check
# Script    : pknca_nca_10min.R
# Purpose   : Simulate single-dose oral PK profiles (1-compartment model with
#             between-subject variability and residual error), run NCA with
#             PKNCA on each virtual trial, and compare the NCA estimates with
#             the true model values. Repeats for RUN_MINUTES (default 10).
# Metrics   : Cmax, Tmax, AUClast, AUCinf, terminal half-life, CL/F, Vz/F
# Software  : R with the PKNCA package (install.packages("PKNCA"))
# Run       : source() in the RStudio console, Source button, background job,
#             or Rscript. Stop early with Stop / Esc / Ctrl+C (summary is
#             still written).
# Output    : ./pknca_output/{data,tables,logs}
# Units     : time h, dose mg, concentration mg/L, AUC mg*h/L, CL L/h, V L
# ==============================================================================

# ---- 0. Packages --------------------------------------------------------------
if (!requireNamespace("PKNCA", quietly = TRUE)) {
  stop("Package 'PKNCA' is not installed. Run: install.packages(\"PKNCA\")")
}
suppressPackageStartupMessages(library(PKNCA))

# ---- 1. Run control -----------------------------------------------------------
RUN_MINUTES         <- 10     # total wall-clock run time
N_SUBJ              <- 40     # subjects per virtual trial
TARGET_REPS_PER_SEC <- 1      # pacing; Inf = flat out
LOG_EVERY_SECONDS   <- 30
SEED                <- 20261022
OUT_ROOT            <- file.path(getwd(), "pknca_output")

# ---- 2. Model and design --------------------------------------------------------
THETA  <- c(CL = 5, V = 50, KA = 1.0)       # L/h, L, 1/h at 70 kg
OMEGA_SD <- c(CL = 0.30, V = 0.25, KA = 0.40)
OMEGA_CORR_CLV <- 0.5
SIGMA_PROP <- 0.15
SIGMA_ADD  <- 0.02                           # mg/L
DOSE       <- 100                            # mg, single oral dose
OBS_TIMES  <- c(0, 0.25, 0.5, 1, 2, 3, 4, 6, 8, 12, 16, 24, 36, 48)

# ---- 3. Directories and logging --------------------------------------------------
dirs <- file.path(OUT_ROOT, c("data", "tables", "logs"))
for (d in dirs) {
  if (!dir.exists(d)) dir.create(d, recursive = TRUE)
  if (!dir.exists(d)) stop("Cannot create directory: ", d)
}
invisible(file.remove(list.files(dirs,
  pattern = "^(nca_subject_results_rep001|nca_replicate_summary|nca_summary|run_summary|run_log|session_info)",
  full.names = TRUE)))
RUN_LOG <- file.path(OUT_ROOT, "logs", "run_log.txt")
t_start <- Sys.time()
elapsed <- function() as.numeric(difftime(Sys.time(), t_start, units = "secs"))
say <- function(...) {
  msg <- sprintf("[%7.1fs] %s", elapsed(), sprintf(...))
  cat(msg, "\n", sep = ""); flush.console()
  cat(msg, "\n", sep = "", file = RUN_LOG, append = TRUE)
}
set.seed(SEED)
writeLines(capture.output(sessionInfo()), file.path(OUT_ROOT, "logs", "session_info.txt"))

# ---- 4. Functions ------------------------------------------------------------------
omega <- diag(OMEGA_SD^2)
omega[1, 2] <- omega[2, 1] <- OMEGA_CORR_CLV * OMEGA_SD["CL"] * OMEGA_SD["V"]

simulate_trial <- function(n) {
  wt  <- pmin(pmax(70 * exp(rnorm(n, 0, 0.20)), 40), 140)
  eta <- matrix(rnorm(n * 3), n, 3) %*% chol(omega)
  CL  <- as.numeric(THETA["CL"] * (wt / 70)^0.75 * exp(eta[, 1]))
  V   <- as.numeric(THETA["V"]  * (wt / 70)      * exp(eta[, 2]))
  KA  <- as.numeric(THETA["KA"] * exp(eta[, 3]))
  K   <- CL / V
  KA  <- ifelse(abs(KA - K) < 1e-4, KA + 1e-3, KA)       # avoid KA == K
  tm  <- matrix(rep(OBS_TIMES, each = n), n, length(OBS_TIMES))
  ipred <- DOSE * KA / (V * (KA - K)) * (exp(-K * tm) - exp(-KA * tm))
  conc  <- ipred * (1 + rnorm(length(ipred), 0, SIGMA_PROP)) + rnorm(length(ipred), 0, SIGMA_ADD)
  conc  <- pmax(conc, 0)
  conc[, 1] <- 0                                           # pre-dose
  list(
    conc = data.frame(ID = rep(seq_len(n), times = length(OBS_TIMES)),
                      time = rep(OBS_TIMES, each = n), conc = as.vector(conc)),
    dose = data.frame(ID = seq_len(n), time = 0, dose = DOSE),
    truth = data.frame(ID = seq_len(n), WT = round(wt, 1), CL_true = CL, V_true = V,
                       KA_true = KA, AUCINF_true = DOSE / CL, THALF_true = log(2) / K))
}

INTERVALS <- data.frame(start = 0, end = Inf, cmax = TRUE, tmax = TRUE, auclast = TRUE,
                        aucinf.obs = TRUE, half.life = TRUE, cl.obs = TRUE, vz.obs = TRUE)

run_nca <- function(tr) {
  co  <- PKNCAconc(tr$conc, conc ~ time | ID)
  dos <- PKNCAdose(tr$dose, dose ~ time | ID)
  res <- suppressWarnings(suppressMessages(pk.nca(PKNCAdata(co, dos, intervals = INTERVALS))))
  long <- as.data.frame(res)
  w <- tidyr::pivot_wider(long[, c("ID", "PPTESTCD", "PPORRES")],
                          names_from = "PPTESTCD", values_from = "PPORRES")
  as.data.frame(w)
}

geomean <- function(x) { x <- x[is.finite(x) & x > 0]; if (length(x)) exp(mean(log(x))) else NA_real_ }

# ---- 5. Main loop --------------------------------------------------------------------
say("Output directory: %s", normalizePath(OUT_ROOT))
say("NCA of %d simulated subjects per trial for %.1f min", N_SUBJ, RUN_MINUTES)

MAX_REPS <- 100000
cols <- c("REP", "CMAX_GM", "AUCLAST_GM", "AUCINF_GM", "CLF_GM", "CLF_TRUE_GM",
          "CLF_BIAS_PCT", "THALF_MEDIAN", "THALF_TRUE_MEDIAN", "FRAC_LAMBDAZ_OK")
res_mat <- matrix(NA_real_, MAX_REPS, length(cols), dimnames = list(NULL, cols))
n_rep <- 0; last_log <- 0; stop_reason <- "completed"

tryCatch({
  while (elapsed() < RUN_MINUTES * 60 && n_rep < MAX_REPS) {
    n_rep <- n_rep + 1
    tr  <- simulate_trial(N_SUBJ)
    nca <- run_nca(tr)
    m   <- merge(nca, tr$truth, by = "ID")
    res_mat[n_rep, ] <- c(
      n_rep, geomean(m$cmax), geomean(m$auclast), geomean(m$aucinf.obs),
      geomean(m$cl.obs), geomean(m$CL_true),
      100 * (geomean(m$cl.obs) / geomean(m$CL_true) - 1),
      median(m$half.life, na.rm = TRUE), median(m$THALF_true),
      mean(is.finite(m$aucinf.obs)))
    if (n_rep == 1) {
      num <- vapply(m, is.numeric, logical(1))
      m[num] <- lapply(m[num], round, 5)
      write.csv(m, file.path(OUT_ROOT, "data", "nca_subject_results_rep001.csv"),
                row.names = FALSE, quote = FALSE)
    }
    if (elapsed() - last_log >= LOG_EVERY_SECONDS) {
      say("trial %4d | Cmax GM %.3f | AUCinf GM %.2f | CL/F GM %.3f | CL bias %+.1f%%",
          n_rep, res_mat[n_rep, "CMAX_GM"], res_mat[n_rep, "AUCINF_GM"],
          res_mat[n_rep, "CLF_GM"], res_mat[n_rep, "CLF_BIAS_PCT"])
      last_log <- elapsed()
    }
    if (is.finite(TARGET_REPS_PER_SEC)) {
      ahead <- n_rep / TARGET_REPS_PER_SEC - elapsed()
      if (ahead > 0) Sys.sleep(ahead)
    }
  }
}, interrupt = function(e) {
  stop_reason <<- "stopped manually"
}, error = function(e) {
  stop_reason <<- paste("error:", conditionMessage(e))
  message("ERROR: ", conditionMessage(e))
})

# ---- 6. Summaries (also after a manual stop) ---------------------------------------------
smry <- NULL
if (n_rep > 0) {
  rs <- as.data.frame(res_mat[seq_len(n_rep), , drop = FALSE])
  write.csv(round(rs, 5), file.path(OUT_ROOT, "tables", "nca_replicate_summary.csv"),
            row.names = FALSE, quote = FALSE)
  keep <- setdiff(cols, "REP")
  smry <- data.frame(METRIC = keep,
                     MEDIAN = sapply(rs[keep], median, na.rm = TRUE),
                     LO95   = sapply(rs[keep], quantile, 0.025, na.rm = TRUE),
                     HI95   = sapply(rs[keep], quantile, 0.975, na.rm = TRUE),
                     row.names = NULL)
  write.csv(data.frame(METRIC = smry$METRIC, round(smry[, -1], 4)),
            file.path(OUT_ROOT, "tables", "nca_summary.csv"), row.names = FALSE, quote = FALSE)
}
summ <- c("NCA SIMULATION CHECK (PKNCA) - RUN SUMMARY",
          sprintf("Finished because: %s", stop_reason),
          sprintf("Runtime:          %.1f s (%.2f min)", elapsed(), elapsed() / 60),
          sprintf("Trials:           %d x %d subjects", n_rep, N_SUBJ),
          sprintf("PKNCA version:    %s", as.character(packageVersion("PKNCA"))),
          sprintf("Output directory: %s", normalizePath(OUT_ROOT)))
writeLines(summ, file.path(OUT_ROOT, "logs", "run_summary.txt"))
cat("\n", paste(summ, collapse = "\n"), "\n", sep = "")
if (!is.null(smry)) {
  cat("\nNCA estimates (median and 95% range across trials):\n")
  print(smry, row.names = FALSE, digits = 4)
}
