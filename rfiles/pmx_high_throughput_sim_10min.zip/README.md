# Population PK Monte Carlo simulation (R) - 10 minute high-throughput run

`pmx_high_throughput_sim.R` is laid out the way a pharmacometrics simulation
script usually is: header block with purpose/model/units, run control,
THETA/OMEGA/SIGMA model specification, dosing and sampling design,
functions, simulation loop, post-processing and logged outputs. Base R only.

## Model
- One-compartment oral PK, first-order absorption, analytical solution
  (no ODE solver, no packages): CL 5 L/h, V 50 L, KA 1 /h at 70 kg
- Allometric WT effect (CL 0.75, V 1.0); covariates WT, SEX, AGE
- Log-normal BSV: CL 30%, V 25%, KA 40%, corr(CL,V) = 0.5
- Combined residual error (15% proportional + 0.02 mg/L additive);
  BLQ (LLOQ 0.05 mg/L) handled M5-style (LLOQ/2, flagged)
- 100 mg QD x 7 days; rich sampling on day 1 and day 7

## What it does
Each "replicate" is a virtual trial of 200 subjects. The script simulates
replicates at a target of 2,000 subjects/s (about 10 replicates/s) for 10
minutes (about 1.2 million subjects, 6,000 replicates). Edit `RUN_MINUTES`,
`N_SUBJ`, `TARGET_SUBJ_PER_SEC` (Inf = flat out) at the top.

## Outputs (`pmx_sim_output/` in the working directory)
- `data/nm_dataset_rep001-003.csv` NONMEM-style event dataset
  (REP, ID, TIME, AMT, DV, EVID, CMT, MDV, BLQ, WT, SEX, AGE; "." = missing)
- `tables/pk_params_part_NNN.csv` per-subject CL, V, KA and steady-state
  Cmax, Tmax, AUCtau, Ctrough, half-life
- `tables/replicate_summary.csv` per-replicate geometric means, GCV%, PTA
  (Ctrough >= 0.2 mg/L), fraction BLQ
- `tables/vpc_by_replicate.csv`, `tables/vpc_summary.csv` 5th/50th/95th
  percentiles per sampling time and their across-replicate 90% intervals
  (VPC-style prediction intervals)
- `tables/exposure_summary.csv` median and 95% range of exposure and PTA
- `logs/` run_log.txt, throughput_log.csv, model_spec.txt, session_info.txt,
  run_summary.txt

Roughly 100-150 MB for the default 10-minute run.

## Run
`source("pmx_high_throughput_sim.R")` in the console, as a background job, or
`Rscript pmx_high_throughput_sim.R`. Stop early with Stop / Esc / Ctrl+C;
files are closed and the summaries are still written.

## Notes
- AUCtau uses a linear trapezoid on a 0.5 h grid (within ~1.5% of the exact
  DOSE/CL). Concentrations are analytical, so no solver tolerance issues.
- Seeded (`SEED`), so a rerun reproduces the same results.
