# ==============================================================================
# Project   : Population PK Monte Carlo simulation - high-throughput stress run
# Script    : pmx_high_throughput_sim.R
# Purpose   : Simulate many virtual trials (replicates) of a one-compartment
#             oral PK model with between-subject variability (BSV), covariates
#             and residual error, for a fixed wall-clock time (default 10 min).
#             Produces a NONMEM-style dataset, per-subject exposure metrics
#             (Cmax, Tmax, AUCtau, Ctrough at steady state), probability of
#             target attainment (PTA) and VPC-style prediction intervals.
# Model     : 1-cmt, first-order absorption, first-order elimination
#             CL (L/h), V (L), KA (1/h);  CL ~ WT^0.75, V ~ WT^1.0
#             Log-normal BSV with CL-V correlation; combined (prop + add) error
# Dosing    : 100 mg QD x 7 days (oral, CMT 1; observations in CMT 2 = central)
# Software  : base R only (no packages). Analytical solution - no ODE solver.
# Run       : source() in console, RStudio/Workbench job, or Rscript.
#             Stop early with Stop / Esc / Ctrl+C; outputs are closed cleanly.
# Output    : ./pmx_sim_output/{data,tables,logs}  (see "OUTPUTS" below)
# Units     : time h, dose mg, concentration mg/L, AUC mg*h/L
# ==============================================================================

# ---- 0. Run control -----------------------------------------------------------
RUN_MINUTES        <- 10      # total wall-clock run time
N_SUBJ             <- 200     # virtual subjects per replicate (trial)
TARGET_SUBJ_PER_SEC <- 2000   # throughput target; Inf = run flat out
SAVE_DATASET_REPS  <- 3       # write full NONMEM-style dataset for first N reps
ROTATE_ROWS        <- 250000  # rows per per-subject table file
LOG_EVERY_SECONDS  <- 10
SEED               <- 20261012
OUT_ROOT           <- file.path(getwd(), "pmx_sim_output")

# ---- 1. Model specification (THETA / OMEGA / SIGMA) --------------------------
THETA <- c(CL = 5,    # typical clearance, L/h  (70 kg)
           V  = 50,   # typical volume, L       (70 kg)
           KA = 1.0)  # absorption rate constant, 1/h
WT_REF   <- 70
WT_EXP   <- c(CL = 0.75, V = 1.0)          # allometric exponents

# OMEGA: variances of log-normal etas (CL, V, KA); corr(CL,V) = 0.5
OMEGA_SD   <- c(CL = 0.30, V = 0.25, KA = 0.40)
OMEGA_CORR <- matrix(c(1.0, 0.5, 0.0,
                       0.5, 1.0, 0.0,
                       0.0, 0.0, 1.0), 3, 3, byrow = TRUE)
OMEGA <- OMEGA_CORR * outer(OMEGA_SD, OMEGA_SD)

# SIGMA: combined residual error  DV = IPRED*(1 + eps1) + eps2
SIGMA_PROP <- 0.15        # proportional SD
SIGMA_ADD  <- 0.02        # additive SD, mg/L
LLOQ       <- 0.05        # mg/L; BLQ records set to LLOQ/2 and flagged (M5)

# Dosing and sampling design
DOSE       <- 100
TAU        <- 24
N_DOSES    <- 7
DOSE_TIMES <- (seq_len(N_DOSES) - 1) * TAU
LAST_DOSE  <- max(DOSE_TIMES)
OBS_TIMES  <- sort(unique(c(c(0.5, 1, 2, 4, 8, 12),                 # day 1
                            LAST_DOSE + c(0, 0.5, 1, 2, 4, 8, 12, TAU))))  # day 7
SS_GRID    <- LAST_DOSE + seq(0, TAU, by = 0.5)    # grid for NCA at SS (linear trapezoid;
                                                   # AUCtau within ~1.5% of exact DOSE/CL)
TARGET_CTROUGH <- 0.2     # mg/L, PTA threshold

# ---- 2. Directories, logging ---------------------------------------------------
DIR_DATA   <- file.path(OUT_ROOT, "data")
DIR_TABLES <- file.path(OUT_ROOT, "tables")
DIR_LOGS   <- file.path(OUT_ROOT, "logs")
for (d in c(DIR_DATA, DIR_TABLES, DIR_LOGS)) {
  if (!dir.exists(d)) dir.create(d, recursive = TRUE)
  if (!dir.exists(d)) stop("Cannot create directory: ", d)
}
# clean previous run outputs only (never touches other files)
invisible(file.remove(list.files(c(DIR_DATA, DIR_TABLES, DIR_LOGS),
  pattern = "^(nm_dataset_rep|pk_params_part|replicate_summary|vpc_by_replicate|vpc_summary|exposure_summary|throughput_log|run_summary|model_spec|session_info)",
  full.names = TRUE)))

RUN_LOG <- file.path(DIR_LOGS, "run_log.txt")
if (file.exists(RUN_LOG)) invisible(file.remove(RUN_LOG))
t_start <- Sys.time()
elapsed <- function() as.numeric(difftime(Sys.time(), t_start, units = "secs"))
say <- function(...) {
  msg <- sprintf("[%7.1fs] %s", elapsed(), sprintf(...))
  cat(msg, "\n", sep = ""); flush.console()
  cat(msg, "\n", sep = "", file = RUN_LOG, append = TRUE)
}

set.seed(SEED)

# ---- 3. Functions ----------------------------------------------------------------
# Concentration (central compartment) after repeated oral doses, one row/subject
conc_matrix <- function(times, CL, V, KA) {
  n  <- length(CL)
  K  <- CL / V
  KA <- ifelse(abs(KA - K) < 1e-4, KA + 1e-3, KA)       # avoid KA == K singularity
  f  <- DOSE * KA / (V * (KA - K))
  out <- matrix(0, n, length(times))
  tm  <- matrix(rep(times, each = n), n, length(times))
  for (td in DOSE_TIMES) {
    tt  <- tm - td
    pos <- tt >= 0
    tt  <- pmax(tt, 0)
    out <- out + pos * f * (exp(-K * tt) - exp(-KA * tt))
  }
  out
}

simulate_subjects <- function(n) {
  wt  <- pmin(pmax(70 * exp(rnorm(n, 0, 0.20)), 40), 140)
  sex <- rbinom(n, 1, 0.5)
  age <- round(pmin(pmax(rnorm(n, 45, 12), 18), 80))
  eta <- matrix(rnorm(n * 3), n, 3) %*% chol(OMEGA)     # cov(eta) = OMEGA
  CL  <- THETA["CL"] * (wt / WT_REF)^WT_EXP["CL"] * exp(eta[, 1])
  V   <- THETA["V"]  * (wt / WT_REF)^WT_EXP["V"]  * exp(eta[, 2])
  KA  <- THETA["KA"] * exp(eta[, 3])
  data.frame(ID = seq_len(n), WT = wt, SEX = sex, AGE = age,
             CL = as.numeric(CL), V = as.numeric(V), KA = as.numeric(KA))
}

add_error <- function(ipred) {
  ipred * (1 + rnorm(length(ipred), 0, SIGMA_PROP)) +
    rnorm(length(ipred), 0, SIGMA_ADD)
}

geomean <- function(x) exp(mean(log(x)))

# NONMEM-style event dataset for one replicate (doses + observations)
build_nm_dataset <- function(rep_id, subj, dv, blq) {
  n <- nrow(subj); no <- length(OBS_TIMES); nd <- N_DOSES
  dose_rows <- data.frame(REP = rep_id, ID = rep(subj$ID, each = nd),
                          TIME = rep(DOSE_TIMES, times = n), AMT = DOSE, DV = NA_real_,
                          EVID = 1L, CMT = 1L, MDV = 1L, BLQ = 0L)
  obs_rows  <- data.frame(REP = rep_id, ID = rep(subj$ID, each = no),
                          TIME = rep(OBS_TIMES, times = n), AMT = NA_real_,
                          DV = as.vector(t(dv)), EVID = 0L, CMT = 2L, MDV = 0L,
                          BLQ = as.integer(as.vector(t(blq))))
  d <- rbind(dose_rows, obs_rows)
  d <- merge(d, subj[, c("ID", "WT", "SEX", "AGE")], by = "ID", sort = FALSE)
  d <- d[order(d$ID, d$TIME, -d$EVID), ]
  d[, c("REP", "ID", "TIME", "AMT", "DV", "EVID", "CMT", "MDV", "BLQ", "WT", "SEX", "AGE")]
}

# ---- 4. Output files -------------------------------------------------------------
f_rep  <- file.path(DIR_TABLES, "replicate_summary.csv")
f_vpc  <- file.path(DIR_TABLES, "vpc_by_replicate.csv")
f_tput <- file.path(DIR_LOGS,   "throughput_log.csv")
writeLines("REP,N,AUCTAU_GM,CMAX_GM,CTROUGH_GM,AUCTAU_GCV,PTA_CTROUGH,FRAC_BLQ", f_rep)
writeLines("REP,TIME,P05,P50,P95", f_vpc)
writeLines("elapsed_s,replicates,subjects,subjects_per_s_interval,subjects_per_s_overall,behind_schedule_reps", f_tput)

pk_con <- NULL; pk_part <- 0; pk_rows <- 0
PK_COLS <- c("REP", "ID", "WT", "SEX", "AGE", "CL", "V", "KA", "CMAX_SS", "TMAX_SS",
             "AUCTAU_SS", "CTROUGH_SS", "THALF")
open_pk_part <- function() {
  if (!is.null(pk_con)) close(pk_con)
  pk_part <<- pk_part + 1; pk_rows <<- 0
  pk_con <<- file(file.path(DIR_TABLES, sprintf("pk_params_part_%03d.csv", pk_part)), "w")
  writeLines(paste(PK_COLS, collapse = ","), pk_con)
}

writeLines(c(
  "MODEL SPECIFICATION",
  "1-compartment oral PK, analytical solution; log-normal BSV; combined error",
  sprintf("THETA: CL=%g L/h, V=%g L, KA=%g 1/h (reference WT %g kg)", THETA["CL"], THETA["V"], THETA["KA"], WT_REF),
  sprintf("Allometric exponents: CL %g, V %g", WT_EXP["CL"], WT_EXP["V"]),
  sprintf("OMEGA SD (log scale): CL %g, V %g, KA %g; corr(CL,V)=%g", OMEGA_SD["CL"], OMEGA_SD["V"], OMEGA_SD["KA"], OMEGA_CORR[1, 2]),
  sprintf("SIGMA: proportional SD %g, additive SD %g mg/L; LLOQ %g mg/L (M5: LLOQ/2)", SIGMA_PROP, SIGMA_ADD, LLOQ),
  sprintf("Dosing: %g mg q%gh x %d; observations at %s h", DOSE, TAU, N_DOSES, paste(OBS_TIMES, collapse = ", ")),
  sprintf("Replicates: N=%d subjects each; seed %d", N_SUBJ, SEED)),
  file.path(DIR_LOGS, "model_spec.txt"))
writeLines(capture.output(sessionInfo()), file.path(DIR_LOGS, "session_info.txt"))

# ---- 5. Main simulation loop -----------------------------------------------------
say("Output directory: %s", normalizePath(OUT_ROOT))
say("Simulating %d subjects/replicate for %.1f min (target %s subjects/s)",
    N_SUBJ, RUN_MINUTES, format(TARGET_SUBJ_PER_SEC, scientific = FALSE))

rep_id <- 0; n_subj_total <- 0; behind <- 0
last_log_t <- 0; last_log_n <- 0
stop_reason <- "completed"

tryCatch({
  open_pk_part()
  while (elapsed() < RUN_MINUTES * 60) {
    rep_id <- rep_id + 1
    subj   <- simulate_subjects(N_SUBJ)

    # Observations at the sampling design (with residual error and BLQ handling)
    ipred <- conc_matrix(OBS_TIMES, subj$CL, subj$V, subj$KA)
    dv    <- pmax(add_error(ipred), 0)
    blq   <- dv < LLOQ
    dv[blq] <- LLOQ / 2

    # Steady-state NCA on a dense grid (no residual error)
    css   <- conc_matrix(SS_GRID, subj$CL, subj$V, subj$KA)
    ng    <- ncol(css)
    auc   <- rowSums((css[, -1] + css[, -ng]) / 2) * 0.5
    imax  <- max.col(css, ties.method = "first")
    cmax  <- css[cbind(seq_len(N_SUBJ), imax)]
    tmax  <- SS_GRID[imax] - LAST_DOSE
    ctr   <- css[, ng]
    thalf <- log(2) / (subj$CL / subj$V)

    pk <- data.frame(REP = rep_id, subj, CMAX_SS = cmax, TMAX_SS = tmax,
                     AUCTAU_SS = auc, CTROUGH_SS = ctr, THALF = thalf)
    pk <- pk[, PK_COLS]
    if (pk_rows + N_SUBJ > ROTATE_ROWS) open_pk_part()
    write.table(round(pk, 5), pk_con, sep = ",", row.names = FALSE, col.names = FALSE, quote = FALSE)
    pk_rows <- pk_rows + N_SUBJ

    # Replicate-level summaries (exposure, PTA) and VPC percentiles
    cat(sprintf("%d,%d,%.5f,%.5f,%.5f,%.3f,%.4f,%.4f\n", rep_id, N_SUBJ,
                geomean(auc), geomean(cmax), geomean(pmax(ctr, 1e-9)),
                100 * sqrt(exp(sd(log(auc))^2) - 1), mean(ctr >= TARGET_CTROUGH), mean(blq)),
        file = f_rep, append = TRUE)
    q <- apply(dv, 2, quantile, probs = c(0.05, 0.5, 0.95), names = FALSE)
    write.table(data.frame(rep_id, OBS_TIMES, round(t(q), 5)), f_vpc, sep = ",",
                row.names = FALSE, col.names = FALSE, quote = FALSE, append = TRUE)

    # NONMEM-style dataset for the first few replicates
    if (rep_id <= SAVE_DATASET_REPS) {
      write.table(build_nm_dataset(rep_id, subj, dv, blq),
                  file.path(DIR_DATA, sprintf("nm_dataset_rep%03d.csv", rep_id)),
                  sep = ",", row.names = FALSE, quote = FALSE, na = ".")
    }

    n_subj_total <- n_subj_total + N_SUBJ

    # Throughput log
    now <- elapsed()
    if (now - last_log_t >= LOG_EVERY_SECONDS) {
      flush(pk_con)
      rate_i <- (n_subj_total - last_log_n) / max(now - last_log_t, 1e-9)
      say("rep %5d | %9s subjects | %6.0f subj/s (interval) | %6.0f subj/s (overall)",
          rep_id, format(n_subj_total, big.mark = ",", scientific = FALSE), rate_i, n_subj_total / now)
      cat(sprintf("%.1f,%d,%d,%.0f,%.0f,%d\n", now, rep_id, n_subj_total, rate_i,
                  n_subj_total / now, behind), file = f_tput, append = TRUE)
      last_log_t <- now; last_log_n <- n_subj_total
    }

    # Pacing to the target rate (sleep only when ahead of schedule)
    if (is.finite(TARGET_SUBJ_PER_SEC)) {
      ahead <- n_subj_total / TARGET_SUBJ_PER_SEC - elapsed()
      if (ahead > 0) Sys.sleep(ahead) else behind <- behind + 1
    }
  }
}, interrupt = function(e) {
  stop_reason <<- "stopped manually"
}, error = function(e) {
  stop_reason <<- paste("error:", conditionMessage(e))
  message("ERROR: ", conditionMessage(e))
}, finally = {
  if (!is.null(pk_con)) { try(close(pk_con), silent = TRUE); pk_con <- NULL }
})

# ---- 6. Post-processing (runs also after a manual stop) -----------------------
if (rep_id > 0) {
  rs <- read.csv(f_rep)
  vp <- read.csv(f_vpc)
  # VPC summary: median and 90% interval (across replicates) of each percentile
  vpc <- do.call(rbind, lapply(split(vp, vp$TIME), function(d) {
    data.frame(TIME = d$TIME[1], NREP = nrow(d),
               P05_LO = quantile(d$P05, 0.05), P05_MED = median(d$P05), P05_HI = quantile(d$P05, 0.95),
               P50_LO = quantile(d$P50, 0.05), P50_MED = median(d$P50), P50_HI = quantile(d$P50, 0.95),
               P95_LO = quantile(d$P95, 0.05), P95_MED = median(d$P95), P95_HI = quantile(d$P95, 0.95),
               row.names = NULL)
  }))
  write.csv(round(vpc, 5), file.path(DIR_TABLES, "vpc_summary.csv"), row.names = FALSE, quote = FALSE)
  expo <- data.frame(
    METRIC = c("AUCTAU_GM", "CMAX_GM", "CTROUGH_GM", "PTA_CTROUGH"),
    MEDIAN = sapply(rs[c("AUCTAU_GM", "CMAX_GM", "CTROUGH_GM", "PTA_CTROUGH")], median),
    LO95   = sapply(rs[c("AUCTAU_GM", "CMAX_GM", "CTROUGH_GM", "PTA_CTROUGH")], quantile, 0.025),
    HI95   = sapply(rs[c("AUCTAU_GM", "CMAX_GM", "CTROUGH_GM", "PTA_CTROUGH")], quantile, 0.975),
    row.names = NULL)
  write.csv(expo, file.path(DIR_TABLES, "exposure_summary.csv"), row.names = FALSE, quote = FALSE)
}

sizes <- file.info(list.files(OUT_ROOT, recursive = TRUE, full.names = TRUE))$size
summ <- c("POPULATION PK SIMULATION - RUN SUMMARY",
          sprintf("Finished because:   %s", stop_reason),
          sprintf("Runtime:            %.1f s (%.2f min)", elapsed(), elapsed() / 60),
          sprintf("Replicates:         %d x %d subjects", rep_id, N_SUBJ),
          sprintf("Subjects simulated: %s", format(n_subj_total, big.mark = ",", scientific = FALSE)),
          sprintf("Avg throughput:     %.0f subjects/s (target %s)", n_subj_total / max(elapsed(), 1e-9),
                  format(TARGET_SUBJ_PER_SEC, scientific = FALSE)),
          sprintf("Reps behind sched.: %d", behind),
          sprintf("Output size:        %.1f MB", sum(sizes) / 1024^2),
          sprintf("Output directory:   %s", normalizePath(OUT_ROOT)))
writeLines(summ, file.path(DIR_LOGS, "run_summary.txt"))
cat("\n", paste(summ, collapse = "\n"), "\n", sep = "")
if (rep_id > 0) { cat("\nExposure summary (median and 95% range across replicates):\n"); print(expo, row.names = FALSE) }
