# ==============================================================================
# Project   : Environment test - R Markdown, Quarto and Shiny
# Script    : test_html_reports_shiny.R
# Purpose   : Check that HTML reports and interactive simulators work in this R /
#             RStudio installation. The script writes three small sample files
#             (an R Markdown report, a Quarto report and a Shiny PK simulator),
#             then tests each one and prints a PASS / FAIL / SKIP table:
#               1. Packages and tools available (rmarkdown, knitr, shiny, pandoc,
#                  Quarto)
#               2. R Markdown  -> renders to a self-contained HTML file
#               3. Quarto      -> renders to a self-contained HTML file
#               4. Shiny       -> app loads, server logic gives correct PK results
#                                 (shiny::testServer), and the app answers HTTP
#                                 requests when started in a background R process
# Software  : R >= 4.0 with rmarkdown, knitr, shiny (install.packages(c(
#             "rmarkdown", "knitr", "shiny"))). Pandoc and Quarto are bundled with
#             RStudio. Optional: callr (for the live Shiny server test).
# Run       : source() in the RStudio console or Source button, or Rscript.
#             Takes about 1-2 minutes. To try the simulator yourself afterwards,
#             set LAUNCH_APP <- TRUE.
# Output    : ./html_test_output/{sample_files,reports,logs}
# ==============================================================================

# ---- 0. Settings ----------------------------------------------------------------
LAUNCH_APP   <- FALSE   # TRUE = start the Shiny simulator after the tests (blocks until stopped)
OPEN_REPORTS <- FALSE   # TRUE = open the rendered HTML reports in the browser
OUT_ROOT     <- file.path(getwd(), "html_test_output")

# ---- 1. Folders and logging --------------------------------------------------------
dir_samples <- file.path(OUT_ROOT, "sample_files")
dir_reports <- file.path(OUT_ROOT, "reports")
dir_logs    <- file.path(OUT_ROOT, "logs")
for (d in c(dir_samples, dir_reports, dir_logs)) {
  if (!dir.exists(d)) dir.create(d, recursive = TRUE)
  if (!dir.exists(d)) stop("Cannot create directory: ", d)
}
unlink(list.files(c(dir_samples, dir_reports, dir_logs), full.names = TRUE, recursive = TRUE), recursive = TRUE)
for (d in c(dir_samples, dir_reports, dir_logs)) dir.create(d, showWarnings = FALSE, recursive = TRUE)

t_start <- Sys.time()
elapsed <- function() as.numeric(difftime(Sys.time(), t_start, units = "secs"))
say <- function(...) { cat(sprintf("[%6.1fs] %s\n", elapsed(), sprintf(...))); flush.console() }
writeLines(capture.output(sessionInfo()), file.path(dir_logs, "session_info.txt"))

results <- data.frame(TEST = character(), STATUS = character(), DETAIL = character(),
                      stringsAsFactors = FALSE)
record <- function(test, status, detail = "") {
  results[nrow(results) + 1, ] <<- list(test, status, substr(gsub("\\s+", " ", detail), 1, 120))
  say("%-4s %s %s", status, test, if (nzchar(detail)) paste0("- ", substr(gsub("\\s+", " ", detail), 1, 100)) else "")
}
run_test <- function(test, expr) {
  tryCatch({
    detail <- expr
    record(test, "PASS", if (is.character(detail)) detail else "")
  }, error = function(e) record(test, "FAIL", conditionMessage(e)))
}
has_pkg <- function(p) requireNamespace(p, quietly = TRUE)

# ---- 2. Sample files (written by this script) ------------------------------------------
rmd_text <- r"---(---
title: "PK simulation report (R Markdown)"
output:
  html_document:
    self_contained: true
    toc: true
---

## Model

One-compartment oral model, 100 mg once daily for 7 days.
CL = 5 L/h, V = 50 L, KA = 1 /h.

```{r simulate, echo=FALSE}
dose <- 100; cl <- 5; v <- 50; ka <- 1; tau <- 24; n_dose <- 7
k <- cl / v
t <- seq(0, n_dose * tau, by = 0.25)
conc <- numeric(length(t))
for (td in (seq_len(n_dose) - 1) * tau) {
  tt <- t - td; ok <- tt >= 0
  conc[ok] <- conc[ok] + dose * ka / (v * (ka - k)) * (exp(-k * tt[ok]) - exp(-ka * tt[ok]))
}
last <- t >= (n_dose - 1) * tau
cmax <- max(conc[last]); auc <- sum(diff(t[last]) * (head(conc[last], -1) + tail(conc[last], -1)) / 2)
```

## Results

```{r table, echo=FALSE}
knitr::kable(data.frame(Metric = c("Cmax (mg/L)", "AUCtau (mg*h/L)"),
                        Value = round(c(cmax, auc), 2)))
```

```{r plot, echo=FALSE, fig.width=7, fig.height=4}
plot(t, conc, type = "l", lwd = 2, col = "steelblue",
     xlab = "Time (h)", ylab = "Concentration (mg/L)", main = "Concentration-time profile")
```
)---"

qmd_text <- r"---(---
title: "PK simulation report (Quarto)"
format:
  html:
    embed-resources: true
    toc: true
---

## Model

One-compartment oral model, 100 mg once daily for 7 days.
CL = 5 L/h, V = 50 L, KA = 1 /h.

```{r}
#| echo: false
dose <- 100; cl <- 5; v <- 50; ka <- 1; tau <- 24; n_dose <- 7
k <- cl / v
t <- seq(0, n_dose * tau, by = 0.25)
conc <- numeric(length(t))
for (td in (seq_len(n_dose) - 1) * tau) {
  tt <- t - td; ok <- tt >= 0
  conc[ok] <- conc[ok] + dose * ka / (v * (ka - k)) * (exp(-k * tt[ok]) - exp(-ka * tt[ok]))
}
last <- t >= (n_dose - 1) * tau
cmax <- max(conc[last]); auc <- sum(diff(t[last]) * (head(conc[last], -1) + tail(conc[last], -1)) / 2)
```

## Results

```{r}
#| echo: false
knitr::kable(data.frame(Metric = c("Cmax (mg/L)", "AUCtau (mg*h/L)"),
                        Value = round(c(cmax, auc), 2)))
```

```{r}
#| echo: false
#| fig-width: 7
#| fig-height: 4
plot(t, conc, type = "l", lwd = 2, col = "steelblue",
     xlab = "Time (h)", ylab = "Concentration (mg/L)", main = "Concentration-time profile")
```
)---"

app_text <- r"---(library(shiny)

ui <- fluidPage(
  titlePanel("One-compartment oral PK simulator"),
  sidebarLayout(
    sidebarPanel(
      sliderInput("dose", "Dose (mg)", min = 10, max = 500, value = 100, step = 10),
      sliderInput("cl", "CL (L/h)", min = 1, max = 20, value = 5, step = 0.5),
      sliderInput("v", "V (L)", min = 10, max = 200, value = 50, step = 5),
      sliderInput("ka", "KA (1/h)", min = 0.1, max = 4, value = 1, step = 0.1),
      sliderInput("tau", "Dosing interval (h)", min = 6, max = 48, value = 24, step = 6),
      sliderInput("ndoses", "Number of doses", min = 1, max = 14, value = 7, step = 1)
    ),
    mainPanel(
      plotOutput("pk_plot", height = "350px"),
      h4("Exposure in the last dosing interval"),
      tableOutput("metrics"),
      downloadButton("download", "Download profile (CSV)")
    )
  )
)

server <- function(input, output, session) {
  sim <- reactive({
    k  <- input$cl / input$v
    ka <- if (abs(input$ka - k) < 1e-4) input$ka + 1e-3 else input$ka
    t  <- seq(0, input$ndoses * input$tau, by = 0.25)
    conc <- numeric(length(t))
    for (td in (seq_len(input$ndoses) - 1) * input$tau) {
      tt <- t - td; ok <- tt >= 0
      conc[ok] <- conc[ok] + input$dose * ka / (input$v * (ka - k)) *
        (exp(-k * tt[ok]) - exp(-ka * tt[ok]))
    }
    data.frame(time = t, conc = conc)
  })

  metrics_df <- reactive({
    d <- sim()
    last <- d[d$time >= (input$ndoses - 1) * input$tau, ]
    auc <- sum(diff(last$time) * (head(last$conc, -1) + tail(last$conc, -1)) / 2)
    data.frame(Metric = c("Cmax (mg/L)", "Tmax (h)", "AUCtau (mg*h/L)", "Ctrough (mg/L)"),
               Value = round(c(max(last$conc),
                               last$time[which.max(last$conc)] - min(last$time),
                               auc, tail(last$conc, 1)), 3))
  })

  output$pk_plot <- renderPlot({
    d <- sim()
    plot(d$time, d$conc, type = "l", lwd = 2, col = "steelblue",
         xlab = "Time (h)", ylab = "Concentration (mg/L)", main = "Concentration-time profile")
    grid()
  })
  output$metrics <- renderTable(metrics_df())
  output$download <- downloadHandler(
    filename = function() "pk_profile.csv",
    content = function(file) write.csv(sim(), file, row.names = FALSE)
  )
}

shinyApp(ui, server)
)---"

f_rmd <- file.path(dir_samples, "report_sample.Rmd")
f_qmd <- file.path(dir_samples, "report_sample.qmd")
dir_app <- file.path(dir_samples, "shiny_app"); dir.create(dir_app, showWarnings = FALSE)
f_app <- file.path(dir_app, "app.R")
writeLines(rmd_text, f_rmd); writeLines(qmd_text, f_qmd); writeLines(app_text, f_app)
say("Sample files written to %s", normalizePath(dir_samples))

html_checks <- function(f, title) {
  if (!file.exists(f)) stop("HTML file was not created: ", f)
  if (file.size(f) < 5000) stop("HTML file is unexpectedly small")
  html <- paste(readLines(f, warn = FALSE), collapse = "\n")
  for (needle in c(title, "Cmax", "<img", "data:image/png")) {
    if (!grepl(needle, html, fixed = TRUE)) stop("HTML is missing expected content: ", needle)
  }
  sprintf("%s, %.0f KB", basename(f), file.size(f) / 1024)
}

# ---- 3. Tests --------------------------------------------------------------------------
say("Running tests...")

# 3.1 Packages and tools
for (p in c("rmarkdown", "knitr", "shiny")) {
  run_test(paste("Package:", p), {
    if (!has_pkg(p)) stop("not installed - run install.packages(\"", p, "\")")
    paste("version", as.character(packageVersion(p)))
  })
}
pandoc_ok <- has_pkg("rmarkdown") && rmarkdown::pandoc_available()
run_test("Tool: Pandoc", {
  if (!pandoc_ok) stop("Pandoc not found (it is bundled with RStudio)")
  paste("version", as.character(rmarkdown::pandoc_version()))
})
quarto_bin <- local({
  p <- Sys.getenv("QUARTO_PATH")
  if (!nzchar(p) && has_pkg("quarto")) p <- tryCatch(quarto::quarto_path(), error = function(e) "")
  if (is.null(p) || !nzchar(p)) p <- unname(Sys.which("quarto"))
  if (is.null(p) || !nzchar(p)) "" else p
})
if (nzchar(quarto_bin)) {
  qv <- tryCatch(trimws(system2(quarto_bin, "--version", stdout = TRUE, stderr = TRUE))[1], error = function(e) "")
  run_test("Tool: Quarto", paste("version", qv))
} else {
  record("Tool: Quarto", "SKIP", "Quarto not found (bundled with recent RStudio versions)")
}

# 3.2 R Markdown
if (has_pkg("rmarkdown") && has_pkg("knitr") && pandoc_ok) {
  run_test("R Markdown -> HTML", {
    out <- rmarkdown::render(f_rmd, output_dir = dir_reports, quiet = TRUE, envir = new.env())
    html_checks(out, "PK simulation report (R Markdown)")
  })
} else record("R Markdown -> HTML", "SKIP", "needs rmarkdown, knitr and Pandoc")

# 3.3 Quarto
if (nzchar(quarto_bin) && has_pkg("knitr")) {
  run_test("Quarto -> HTML", {
    log <- suppressWarnings(system2(quarto_bin, c("render", shQuote(normalizePath(f_qmd))),
                                    stdout = TRUE, stderr = TRUE))
    out <- file.path(dir_samples, "report_sample.html")
    if (!file.exists(out)) stop("Quarto did not create HTML: ", paste(tail(log, 3), collapse = " "))
    file.copy(out, file.path(dir_reports, "report_sample_quarto.html"), overwrite = TRUE)
    unlink(out)
    html_checks(file.path(dir_reports, "report_sample_quarto.html"), "PK simulation report (Quarto)")
  })
} else record("Quarto -> HTML", "SKIP", "needs Quarto and knitr")

# 3.4 Shiny
if (has_pkg("shiny")) {
  suppressPackageStartupMessages(library(shiny))
  app <- NULL
  run_test("Shiny: app file loads", {
    app <- source(f_app, local = new.env())$value
    if (!inherits(app, "shiny.appobj")) stop("app.R did not return a Shiny app")
    "app.R returns a shiny app object"
  })
  if (!is.null(app)) {
    run_test("Shiny: server logic (testServer)", {
      res <- NULL
      shiny::testServer(app, {
        session$setInputs(dose = 100, cl = 5, v = 50, ka = 1, tau = 24, ndoses = 7)
        d <- sim()
        m <- metrics_df()
        auc <- m$Value[m$Metric == "AUCtau (mg*h/L)"]
        cmax <- m$Value[m$Metric == "Cmax (mg/L)"]
        res <<- list(rows = nrow(d), auc = auc, cmax = cmax)
        session$setInputs(dose = 200)
        res$auc2 <<- metrics_df()$Value[metrics_df()$Metric == "AUCtau (mg*h/L)"]
        res$table_html <<- as.character(output$metrics)
      })
      if (res$rows != 673) stop("expected 673 profile rows, got ", res$rows)
      if (abs(res$auc - 100 / 5) / (100 / 5) > 0.03) stop("AUCtau ", res$auc, " is not close to dose/CL = 20")
      if (abs(res$auc2 / res$auc - 2) > 0.02) stop("doubling the dose did not double AUCtau")
      if (!grepl("Cmax", res$table_html, fixed = TRUE)) stop("metrics table did not render")
      sprintf("rows %d, AUCtau %.2f (dose/CL = 20), Cmax %.2f; 2x dose -> %.2fx AUC",
              res$rows, res$auc, res$cmax, res$auc2 / res$auc)
    })
    if (has_pkg("callr") && has_pkg("httpuv")) {
      run_test("Shiny: live server answers HTTP", {
        port <- httpuv::randomPort()
        bg <- callr::r_bg(function(dir, port) shiny::runApp(dir, port = port, host = "127.0.0.1",
                                                            launch.browser = FALSE),
                          args = list(dir = dir_app, port = port), supervise = TRUE)
        on.exit(try(bg$kill(), silent = TRUE), add = TRUE)
        url <- sprintf("http://127.0.0.1:%d/", port)
        page <- NULL
        for (i in 1:60) {
          if (!bg$is_alive()) stop("server process stopped: ", paste(tail(bg$read_all_error(), 2), collapse = " "))
          page <- tryCatch(suppressWarnings(paste(readLines(url, warn = FALSE), collapse = "\n")),
                           error = function(e) NULL)
          if (!is.null(page)) break
          Sys.sleep(0.5)
        }
        if (is.null(page)) stop("no response from ", url, " after 30 s")
        if (!grepl("One-compartment oral PK simulator", page, fixed = TRUE)) stop("page does not contain the app title")
        sprintf("HTTP response OK on port %d (%d bytes)", port, nchar(page))
      })
    } else record("Shiny: live server answers HTTP", "SKIP", "needs packages callr and httpuv")
  }
} else {
  record("Shiny: app file loads", "SKIP", "shiny not installed")
}

# ---- 4. Summary -------------------------------------------------------------------------
write.csv(results, file.path(dir_logs, "test_results.csv"), row.names = FALSE)
n_fail <- sum(results$STATUS == "FAIL"); n_skip <- sum(results$STATUS == "SKIP")
summ <- c("R MARKDOWN / QUARTO / SHINY TEST - SUMMARY",
          sprintf("Tests: %d passed, %d failed, %d skipped", sum(results$STATUS == "PASS"), n_fail, n_skip),
          sprintf("Runtime: %.1f s", elapsed()),
          sprintf("Reports: %s", normalizePath(dir_reports)),
          sprintf("Shiny app: %s", normalizePath(f_app)))
writeLines(summ, file.path(dir_logs, "test_summary.txt"))
cat("\n")
for (i in seq_len(nrow(results))) {
  cat(sprintf("%-4s  %-36s %s\n", results$STATUS[i], results$TEST[i], results$DETAIL[i]))
}
cat("\n", paste(summ, collapse = "\n"), "\n", sep = "")

if (OPEN_REPORTS) for (f in list.files(dir_reports, "\\.html$", full.names = TRUE)) utils::browseURL(f)
if (LAUNCH_APP && has_pkg("shiny")) {
  say("Starting the Shiny simulator - stop it with the Stop button / Esc / Ctrl+C")
  shiny::runApp(dir_app)
}
invisible(results)
