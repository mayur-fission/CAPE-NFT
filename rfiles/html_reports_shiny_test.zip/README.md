# Test for R Markdown, Quarto and Shiny

`test_html_reports_shiny.R` checks that HTML reports and interactive simulators
work in your R / RStudio installation. It writes three small sample files and
tests them:

| Test | What is checked |
|---|---|
| Packages and tools | rmarkdown, knitr, shiny, Pandoc, Quarto |
| R Markdown | `report_sample.Rmd` renders to a self-contained HTML file with the title, table and plot |
| Quarto | `report_sample.qmd` renders to a self-contained HTML file (skipped if Quarto is missing) |
| Shiny | `app.R` loads; the server logic gives the right PK results (AUCtau = dose/CL, doubling the dose doubles AUC); the app answers HTTP requests when started in a background R process (needs callr, otherwise skipped) |

The sample Shiny app is a one-compartment oral PK simulator with sliders for dose,
CL, V, KA, dosing interval and number of doses, an exposure table and a CSV download.

## Setup (once)
R 4.1 or newer and RStudio (Pandoc and Quarto are bundled with RStudio).
`install.packages(c("rmarkdown", "knitr", "shiny"))`; optionally
`install.packages(c("callr", "httpuv"))` for the live server test.

## Run
Set the working directory, then `source("test_html_reports_shiny.R")` or click
Source. It takes 15-60 seconds and prints a PASS / FAIL / SKIP table. To try the
simulator yourself, set `LAUNCH_APP <- TRUE` at the top (stop it with the Stop
button). `OPEN_REPORTS <- TRUE` opens the HTML reports in the browser.

## Output (`html_test_output/` in the working directory)
- `reports/report_sample.html`, `reports/report_sample_quarto.html`
- `sample_files/` the .Rmd, .qmd and `shiny_app/app.R` you can reuse as templates
- `logs/test_results.csv`, `logs/test_summary.txt`, `logs/session_info.txt`

## If a test fails
The DETAIL column says why. Common causes: a missing package, Pandoc not found
(use RStudio, or install Pandoc), or Quarto not on the path (update RStudio or
install Quarto from quarto.org).
